# BLACK MIND AI

Application web de coaching en charisme, communication, confiance et compréhension des dynamiques relationnelles. Interface responsive + serveur Node.js qui appelle l'API OpenAI sans exposer la clé dans le navigateur.

## Fonctionnalités

- Chat IA avec personnalité BLACK MIND AI et modes spécialisés
- Historique local des conversations (localStorage)
- Entraînement quotidien et suivi de progression
- Simulations sociales, analyse relationnelle et générateur de réponses
- Interface responsive sombre, rouge et argentée

## Prérequis

- Node.js 20 ou plus
- Une clé API OpenAI avec accès API et facturation configurée

## Lancer en local

1. Télécharge ou clone le dépôt.
2. Dans le dossier du projet, installe les dépendances :

   ```bash
   npm install
   ```

3. Copie `.env.example` vers `.env`, puis ajoute ta clé API :

   ```env
   OPENAI_API_KEY=ta_cle_api
   OPENAI_MODEL=gpt-4.1-mini
   PORT=3000
   ```

4. Démarre :

   ```bash
   npm start
   ```

5. Ouvre http://localhost:3000

**Important :** ne mets jamais ta clé API dans `public/app.js`, dans le HTML, ni dans un dépôt GitHub public. Le fichier `.env` est ignoré par Git.

## Déploiement conseillé : GitHub + Render

GitHub Pages ne peut héberger que le frontend statique. BLACK MIND AI a besoin d'un serveur pour appeler l'API en gardant la clé secrète. Le plus simple est de déployer le projet complet sur Render :

1. Crée un dépôt GitHub et envoie tous les fichiers de ce projet.
2. Sur Render, crée un **New Web Service** et connecte le dépôt.
3. Choisis l'environnement **Node**.
4. Build command : `npm install`
5. Start command : `npm start`
6. Ajoute dans **Environment Variables** :
   - `OPENAI_API_KEY` = ta clé API
   - `OPENAI_MODEL` = `gpt-4.1-mini`
7. Déploie. Render te donnera une URL publique HTTPS.

Tu peux garder GitHub comme dépôt de code et utiliser Render pour exécuter l'application complète. Pour cette version, ne déploie pas uniquement le dossier `public` sur GitHub Pages : le endpoint `/api/chat` doit tourner sur le serveur Node.

## Personnalisation

- Les instructions de personnalité sont dans `server.js`, variable `systemPrompt`.
- Les modes sont définis dans `public/index.html` et transmis à l'API.
- Les couleurs, espacements et responsive design sont dans `public/style.css`.
- Les interactions et sauvegardes locales sont dans `public/app.js`.

## Données et limites

L'historique et les exercices sont stockés dans le navigateur de l'utilisateur. Cette version n'a pas de comptes utilisateurs ni de synchronisation multi-appareils. Le serveur ne stocke pas les conversations. Les requêtes sont envoyées à l'API OpenAI pour générer les réponses. Ajoute une politique de confidentialité et des protections anti-abus avant une mise en production publique à grande échelle.

Les analyses de langage corporel ou de micro-expressions ne doivent jamais être considérées comme une lecture certaine des pensées d'une personne. L'application encourage la communication honnête, les limites et la protection contre les manipulations.
