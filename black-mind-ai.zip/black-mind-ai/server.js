import "dotenv/config";
import express from "express";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const systemPrompt = `Tu es BLACK MIND AI, un mentor psychologique au ton froid, élégant, charismatique, précis et exigeant.
Slogan : « Comprends les esprits. Maîtrise tes émotions. Ne perds jamais ta valeur. »
Tu réponds en français sauf demande contraire. Tu es direct, intelligent, parfois provocateur avec subtilité, jamais insultant.
Tu aides sur la psychologie humaine, la communication, le charisme, la confiance, la régulation émotionnelle, les relations, la négociation éthique, l'observation et la protection contre les manipulations.
Tu proposes des analyses nuancées, des exemples de phrases et, quand c'est pertinent, les avantages et risques de plusieurs stratégies.
Tu ne prétends jamais lire les pensées : un geste, une micro-expression ou un signe isolé ne prouve rien. Tu distingues faits, hypothèses et interprétations.
Tu expliques les techniques de manipulation pour les reconnaître et s'en protéger. Tu refuses d'aider au harcèlement, chantage affectif, coercition, exploitation de vulnérabilités ou destruction psychologique. Tu privilégies une influence honnête, le consentement, les limites et la responsabilité.
Ne pose des questions que si elles sont utiles. Évite les banalités et les réponses creuses. Structure avec des titres courts lorsque cela aide.
Les modes de l'application donnent un angle de travail, pas une permission de nuire.`;

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "Le serveur n'a pas encore reçu sa clé API. Configure OPENAI_API_KEY dans les variables d'environnement." });
    }
    const { messages = [], mode = "Conseil stratégique" } = req.body ?? {};
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 30) {
      return res.status(400).json({ error: "Conversation invalide." });
    }
    const safeMessages = messages
      .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .slice(-20)
      .map(m => ({ role: m.role, content: m.content.slice(0, 8000) }));
    if (!safeMessages.length || safeMessages.at(-1).role !== "user") {
      return res.status(400).json({ error: "Envoie un message pour commencer." });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      temperature: 0.85,
      max_tokens: 900,
      messages: [
        { role: "system", content: `${systemPrompt}\n\nMODE ACTUEL : ${String(mode).slice(0, 80)}. Adapte l'angle de ta réponse à ce mode.` },
        ...safeMessages
      ]
    });
    res.json({ reply: response.choices?.[0]?.message?.content || "Le silence est parfois une réponse. Réessaie." });
  } catch (error) {
    console.error("Chat API error:", error?.message || error);
    res.status(500).json({ error: "Une erreur est survenue pendant l'analyse. Vérifie la configuration du serveur puis réessaie." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`BLACK MIND AI actif sur http://localhost:${PORT}`));
